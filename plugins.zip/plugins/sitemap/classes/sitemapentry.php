<?php
namespace Grav\Plugin;

class SitemapEntry
{
    public $location;
    public $lastmod;
    public $changefreq;
    public $priority;
    public $image;
}
